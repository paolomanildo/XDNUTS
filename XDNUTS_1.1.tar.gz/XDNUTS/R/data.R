#' Blood viscosity data
#'
#' Contains blood viscosity measurements of 6 subject. Each individuals
#' was measure 7 times.
#'
#' @format A data frame with 6 rows and 8 variables:
#'  \describe{
#'  \item{id}{subject identifier.}
#'  \item{Time.1}{viscosity measurments for the first time.},
#'  \item{Time.2}{viscosity measurments for the second time.},
#'  \item{Time.3}{viscosity measurments for the third time.},
#'  \item{Time.4}{viscosity measurments for the fourth time.},
#'  \item{Time.5}{viscosity measurments for the fifth time.},
#'  \item{Time.6}{viscosity measurments for the sixth time.},
#'  \item{Time.7}{viscosity measurments for the seventh time.}}
#'  
#' @source {Master Degree course at University of Padua}
#' @examples
#' data(viscosity)
"viscosity"