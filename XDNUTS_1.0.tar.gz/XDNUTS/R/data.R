#' Blood viscosity data
#'
#' Contains blood viscosity measurements of 6 subject. Each individuals
#' was measure 7 times.
#'
#' @format A data frame with 6 rows and 8 variables:
#'  \describe{
#'  \item{id}{subject identifier.}
#'  \item{Time.1 - Time.7}{viscosity measurments from time 1 to 7.}}
#'  
#' @source {Master Degree course at University of Padua}
#' @examples
#' data(viscosity)
"viscosity"